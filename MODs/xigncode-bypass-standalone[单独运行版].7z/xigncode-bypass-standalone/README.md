# xigncode-bypass for TERA by Caali

Standalone version. It is recommended to use the version with proxy integration instead, because it will be automatically updated. FAQ, help, etc. here: https://discord.gg/maqBmJV 

# Installation
> Extract everything into an empty folder
> Make sure that the latest (v10.4) version of Node.JS is installed on your system (https://nodejs.org/en/)
> Make sure that the Microsoft Visual C++ Redistributables are installed on your system (both x86 and x64, for both 2015 and 2017).

# Usage
> Run `XigncodeBypass.bat` as administrator and leave it running
> Run the game client
> After closing the game client, close the bypass
