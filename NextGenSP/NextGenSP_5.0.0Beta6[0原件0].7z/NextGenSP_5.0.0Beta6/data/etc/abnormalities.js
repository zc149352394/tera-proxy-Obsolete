module.exports = {

	10152085: true, // Mana Missiles (unused)
	10152086: true, // Arc Bomb (unused)
	10153093: true, // Rocket Jump & Rolling Reload (Memory leak >//>[status]) 
};