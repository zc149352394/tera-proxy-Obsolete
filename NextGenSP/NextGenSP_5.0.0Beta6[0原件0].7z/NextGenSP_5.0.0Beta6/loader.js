"use strict";

//------------------------------------
//by SaltyMonkey 
//Reworked loader for skill prediction
//Can detect duplicated modules,
//update configuration and 
//remove deprecated files
//------------------------------------

const {lstatSync,readdirSync,existsSync} = require("fs");
const path = require("path");
const utils = require("./lib/helpers/utils");

/**
 * @description Check path for directory
 * @param {string} source  full path
 * @returns {boolean} true - directory, false - nope
 */
const isDirectory = source => lstatSync(source).isDirectory();

/**
 * @description Check "string" (with short name	for directory) for active proxy module
 * @param {string} source short name
 * @returns {boolean}
 */
const isActiveModule = source => !["_", "."].includes(source[0]);

/**
 * @description Grab short name from full path and translate it to lower case
 * @param {string} source full path
 * @returns {boolean} short name
 */
const getShortDirName = source => (source.slice(source.lastIndexOf(path.sep) + 1, source.length)).toLowerCase();

/**
 * @description Return short names for all active modules from folder with modules
 * @param {string} source 
 * @returns {boolean} short names
 */
const getModules = source =>
	(readdirSync(source).map(name => path.join(source, name))
		.filter(isDirectory))
		.map(elem => getShortDirName(elem))
		.filter(isActiveModule);

//------------------------------------------------------------------------
let blockedModules = ["cooldowns", "shakers", "shakers-master", "lockons-light", "lockon-light", "lockons-light-master", 
	"lockons", "lockons-master", "fastfire", "fast-fire", "fast-fire-master", "fast-block",
	"skill-prediction", "skill-prediction-master", "skill-prediction-exp", "skill-prediction-experimental",
	"cooldowns-master", "fast-block-master", "skillprediction", "pinkie-sp", "sp-pinkie", "best", "bestsp",
	"no-more-wasted-grim-strikes", "grim", "grimstrike", "zsync", "auto-lockon", "let-me-lock", "fix-ghost", "lockon"
];

let errorState = 0;
let installedModules = null;
let installedBlockedModules = [];
let currentDir = getShortDirName(utils.getFullPath(__dirname, "./"));
let updatePath = utils.getFullPath(__dirname,"./data/sp/migration.json");
let originalConfigPath = utils.getFullPath(__dirname,"./config/settings.json");
let defaultConfigFilePath = utils.getFullPath(__dirname,"./data/sp/default-settings.json");
let modulejsonPath = utils.getFullPath(__dirname, "./module.json");
//------------------------------------------------------------------------

//def file check
//errorState = def.checkConsistency();

//all installed modules except current dir
installedModules = (getModules(path.resolve(__dirname, "../../"))).filter(element => element !== currentDir);

//check for blocked modules
for ( let item of installedModules)
	for ( let blk of blockedModules)
		if (item.includes(blk)) {
			errorState = 1;
			installedBlockedModules.push(item);
		}

if (!existsSync(originalConfigPath)) {
	utils.writeWarningMessage("Your config file broken. Fixing...");
	utils.saveJson(updateFile, utils.loadJson(defaultConfigFilePath));
	utils.writeWarningMessage("Config file restored with default values.");
}

let updateFile = utils.loadJson(updatePath);
let originalConfig = utils.loadJson(originalConfigPath);

//run update/cleanup
if (updateFile && originalConfig && originalConfig.version != updateFile["version"]) {
	let diff = utils.compareFieldsInObjects(originalConfig, updateFile["configAdd"]);
	let obj = originalConfig;
	if (diff != null) {
		utils.writeLogMessage("Some values must be updated in config! Updating...");
		obj = Object.assign(originalConfig, diff);
		obj["version"] = updateFile.version;
	}
	if (updateFile["configRemove"]) {
		utils.writeLogMessage("Some values deprecated in config! Removing...");
		for (let field of updateFile["configRemove"])
			if (obj[field]) obj[field] = undefined;
	}
	utils.writeLogMessage("Configuration up to date");
	utils.saveJson(obj, originalConfigPath);
	if (updateFile["removeFile"]) {
		utils.writeLogMessage("Cleanup task...");
		let cleanupObj = updateFile["removeFile"];
		utils.writeLogMessage("Removing deprecated files...");
		utils.writeLogMessage(cleanupObj);
		if (Array.isArray(cleanupObj))
			cleanupObj.forEach((item) => utils.removeByPath(utils.getFullPath(__dirname, item)));
		else
			utils.removeByPath(utils.getFullPath(__dirname, cleanupObj));
		utils.writeLogMessage("Done!");
	}
}

//Main entry point
module.exports = function SpLoader(mod) {
	
	if(!require("tera-data-parser").types)
		errorState = 2;

	if (mod.proxyAuthor != "caali")
		errorState = 3;

	if (!existsSync(modulejsonPath))
		errorState = 4;

	if (errorState !=0) {
		utils.writeErrorMessage(`[${currentDir}] Start cancelled!`);
		switch (errorState){
		case 1: 
			utils.writeErrorMessage("One or more incompatible modules installed!");
			utils.writeErrorMessage("Possible block reason: exploits and/or outdated modules - interfere with sp or dangerous (ban)");
			utils.writeErrorMessage(`Remove them and restart proxy! ${installedBlockedModules}`);
			break;
		case 2:
			utils.writeErrorMessage("Your version of tera-proxy so old. Bye!");
			break;
		case 3: 
			utils.writeErrorMessage("Only Caali proxy supported. Bye!");
			break;
		case 4: 
			utils.writeErrorMessage("You removed module.json. Bye!");
			break;
		case 5:
			utils.writeErrorMessage("Definitions file broke! Bye!");
			break;
		}
		/* eslint-disable no-process-exit */
		process.exit();
	}

	/* eslint-disable no-unused-vars */
	const state = require("./lib/state");
	const core = require("./lib/core")(mod, state);	
	/* eslint-enable no-unused-vars */

};